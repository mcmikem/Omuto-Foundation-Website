document.addEventListener('DOMContentLoaded', () => {
    // 1. Reveal Animations & Advanced Counter Logic
    const observerOptions = {
        threshold: 0.15,
        rootMargin: '0px 0px -50px 0px'
    };

    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('active');
                
                const counter = entry.target.classList.contains('counter') ? entry.target : entry.target.querySelector('.counter');
                if (counter && !counter.dataset.counted) {
                    const target = +counter.getAttribute('data-target');
                    let count = 0;
                    const duration = 2500;
                    const startTime = performance.now();

                    const update = (now) => {
                        const elapsed = now - startTime;
                        const progress = Math.min(elapsed / duration, 1);
                        // Ease-out expo
                        const easedProgress = progress === 1 ? 1 : 1 - Math.pow(2, -10 * progress);
                        
                        count = target * easedProgress;
                        counter.innerText = Math.floor(count).toLocaleString();

                        if (progress < 1) {
                            requestAnimationFrame(update);
                        } else {
                            counter.innerText = target.toLocaleString();
                            counter.dataset.counted = "true";
                        }
                    };
                    requestAnimationFrame(update);
                }
            }
        });
    }, observerOptions);

    document.querySelectorAll('.reveal, .counter').forEach(el => observer.observe(el));

    // 2. Magnetic Buttons Effect
    document.querySelectorAll('.btn-magnetic').forEach(btn => {
        btn.addEventListener('mousemove', (e) => {
            const rect = btn.getBoundingClientRect();
            const x = (e.clientX - rect.left - rect.width / 2) * 0.35;
            const y = (e.clientY - rect.top - rect.height / 2) * 0.35;
            btn.style.transform = `translate(${x}px, ${y}px)`;
        });
        btn.addEventListener('mouseleave', () => {
            btn.style.transform = `translate(0, 0)`;
        });
    });

    // 3. Navigation Scroll State
    const nav = document.getElementById('main-nav');
    if (nav) {
        window.addEventListener('scroll', () => {
            if (window.scrollY > 80) nav.classList.add('nav-scrolled');
            else nav.classList.remove('nav-scrolled');
        }, { passive: true });
    }

    // 4. Mobile Menu Logic
    const mobileMenuBtn = document.getElementById('mobile-menu-btn');
    const mobileMenuOverlay = document.getElementById('mobile-menu-overlay');
    const closeMobileMenu = document.getElementById('close-mobile-menu');

    if (mobileMenuBtn && mobileMenuOverlay && closeMobileMenu) {
        mobileMenuBtn.onclick = () => {
            mobileMenuOverlay.classList.add('active');
            document.body.style.overflow = 'hidden';
        };

        const close = () => {
            mobileMenuOverlay.classList.remove('active');
            document.body.style.overflow = '';
        };

        closeMobileMenu.onclick = close;
        mobileMenuOverlay.querySelectorAll('a').forEach(link => {
            link.onclick = close;
        });
    }
});