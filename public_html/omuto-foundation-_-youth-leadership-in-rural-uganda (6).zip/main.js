document.addEventListener('DOMContentLoaded', () => {
    // 1. Reveal Animations & Intersection Observer
    const observerOptions = {
        threshold: 0.1,
        rootMargin: '0px 0px -100px 0px'
    };

    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('active');
                
                // If it's a counter, trigger the count logic
                const counter = entry.target.querySelector('.counter');
                if (counter && !counter.classList.contains('counted')) {
                    animateCounter(counter);
                }
            }
        });
    }, observerOptions);

    document.querySelectorAll('.reveal').forEach(el => observer.observe(el));

    // 2. Parallax Effect for Editorial Pills
    window.addEventListener('scroll', () => {
        const scrolled = window.pageYOffset;
        document.querySelectorAll('.pill-frame').forEach(pill => {
            const speed = pill.getAttribute('data-speed') || 0.05;
            const yPos = -(scrolled * speed);
            pill.style.transform = `translateY(${yPos}px)`;
        });
    }, { passive: true });

    // 3. Counter Animation Engine
    function animateCounter(el) {
        const target = parseInt(el.getAttribute('data-target'));
        const duration = 2500; // 2.5 seconds
        const start = 0;
        const startTime = performance.now();

        function update(currentTime) {
            const elapsed = currentTime - startTime;
            const progress = Math.min(elapsed / duration, 1);
            
            // Easing function (Out Expo)
            const ease = progress === 1 ? 1 : 1 - Math.pow(2, -10 * progress);
            
            const currentVal = Math.floor(ease * target);
            el.innerText = currentVal.toLocaleString();

            if (progress < 1) {
                requestAnimationFrame(update);
            } else {
                el.innerText = target.toLocaleString();
                el.classList.add('counted');
            }
        }

        requestAnimationFrame(update);
    }

    // 4. Magnetic Buttons logic
    document.querySelectorAll('.btn-magnetic').forEach(btn => {
        btn.addEventListener('mousemove', (e) => {
            const rect = btn.getBoundingClientRect();
            const x = (e.clientX - rect.left - rect.width / 2) * 0.4;
            const y = (e.clientY - rect.top - rect.height / 2) * 0.4;
            btn.style.transform = `translate(${x}px, ${y}px)`;
        });
        btn.addEventListener('mouseleave', () => {
            btn.style.transform = `translate(0, 0)`;
        });
    });

    // 5. Smooth Anchor Scrolling
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            e.preventDefault();
            const target = document.querySelector(this.getAttribute('href'));
            if (target) {
                target.scrollIntoView({
                    behavior: 'smooth',
                    block: 'start'
                });
            }
        });
    });
});