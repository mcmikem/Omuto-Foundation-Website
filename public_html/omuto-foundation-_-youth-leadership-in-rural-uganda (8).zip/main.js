document.addEventListener('DOMContentLoaded', () => {
    // 1. Centralized Mobile Menu Logic
    const menuToggle = document.getElementById('menu-toggle');
    const menuClose = document.getElementById('menu-close');
    const mobileMenu = document.getElementById('mobile-menu');
    const backdrop = document.querySelector('.menu-backdrop');

    function openMenu() {
        if (!mobileMenu) return;
        mobileMenu.classList.add('is-active');
        document.body.style.overflow = 'hidden';
    }

    function closeMenu() {
        if (!mobileMenu) return;
        mobileMenu.classList.remove('is-active');
        document.body.style.overflow = '';
    }

    // Attach to toggle button
    if (menuToggle) {
        menuToggle.addEventListener('click', (e) => {
            e.preventDefault();
            e.stopPropagation();
            openMenu();
        });
    }

    // Attach to close button
    if (menuClose) {
        menuClose.addEventListener('click', (e) => {
            e.preventDefault();
            closeMenu();
        });
    }

    // Backdrop click
    if (backdrop) {
        backdrop.addEventListener('click', closeMenu);
    }

    // Close menu on link clicks
    const menuLinks = mobileMenu ? mobileMenu.querySelectorAll('a') : [];
    menuLinks.forEach(link => {
        link.addEventListener('click', closeMenu);
    });

    // 2. Navigation Scroll Effects
    const nav = document.querySelector('nav');
    const backToTop = document.getElementById('back-to-top');

    window.addEventListener('scroll', () => {
        const scrollY = window.scrollY;
        
        // Sticky Nav logic
        if (scrollY > 50) {
            nav.classList.add('scrolled');
        } else {
            nav.classList.remove('scrolled');
        }

        // Back to top visibility
        if (scrollY > 500) {
            backToTop?.classList.add('visible');
        } else {
            backToTop?.classList.remove('visible');
        }

        // Scroll Progress
        const winScroll = document.body.scrollTop || document.documentElement.scrollTop;
        const height = document.documentElement.scrollHeight - document.documentElement.clientHeight;
        const scrolled = (winScroll / height) * 100;
        const progressBar = document.getElementById('scroll-progress');
        if (progressBar) progressBar.style.width = scrolled + "%";
    });

    // 3. Staggered Entrance Indexer
    document.querySelectorAll('.stagger-group').forEach(group => {
        group.querySelectorAll('.reveal').forEach((el, index) => {
            el.style.setProperty('--stagger-index', index);
        });
    });

    // 4. Statistics Counter Logic
    const counters = document.querySelectorAll('.count-up');
    const countObserver = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                const target = entry.target;
                const countTo = parseInt(target.getAttribute('data-count')) || 0;
                const suffix = target.getAttribute('data-suffix') || '';
                let current = 0;
                const duration = 2500; 
                const frameRate = 1000 / 60;
                const totalFrames = Math.round(duration / frameRate);
                const increment = countTo / totalFrames;
                
                let frame = 0;
                const timer = setInterval(() => {
                    frame++;
                    current += increment;
                    if (frame === totalFrames) {
                        target.innerText = countTo.toLocaleString() + suffix;
                        clearInterval(timer);
                    } else {
                        target.innerText = Math.floor(current).toLocaleString() + suffix;
                    }
                }, frameRate);
                countObserver.unobserve(target);
            }
        });
    }, { threshold: 0.1 });

    counters.forEach(counter => countObserver.observe(counter));

    // 5. Reveal Animations Observer
    const revealObserver = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('active');
            }
        });
    }, { threshold: 0.15, rootMargin: '0px 0px -50px 0px' });

    document.querySelectorAll('.reveal').forEach(el => revealObserver.observe(el));

    // 6. Back to Top Click
    if (backToTop) {
        backToTop.addEventListener('click', () => {
            window.scrollTo({ top: 0, behavior: 'smooth' });
        });
    }

    // 7. Smooth Scroll for links
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            const href = this.getAttribute('href');
            if (href === '#' || href === '') return;
            e.preventDefault();
            const target = document.querySelector(href);
            if (target) {
                target.scrollIntoView({ behavior: 'smooth', block: 'start' });
            }
        });
    });
});